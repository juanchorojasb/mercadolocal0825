export default function Privacy() {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4">
        <h1 className="text-3xl font-bold mb-8">Política de Privacidad</h1>
        <div className="bg-white p-8 rounded-lg">
          <p className="mb-4">Política de privacidad de MercadoLocal Caldas.</p>
          <p>En desarrollo...</p>
        </div>
      </div>
    </div>
  )
}
