// Stub temporal para seed-improved.ts
// TODO: Implementar cuando sea necesario crear datos de prueba

console.log('Seed improved - placeholder')
export {}
