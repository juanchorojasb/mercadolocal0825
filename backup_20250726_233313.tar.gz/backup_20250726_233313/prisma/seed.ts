// Stub temporal para seed.ts
// TODO: Implementar cuando sea necesario crear datos de prueba

console.log('Seed - placeholder')
export {}
