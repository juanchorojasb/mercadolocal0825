import { NextResponse } from 'next/server'

// Stub temporal - Curso individual en desarrollo
export async function GET() {
  return NextResponse.json({ 
    message: 'Curso específico en desarrollo'
  })
}
