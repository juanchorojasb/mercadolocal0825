export function StoreContact({ store }: { store: any }) {
  return null
}
